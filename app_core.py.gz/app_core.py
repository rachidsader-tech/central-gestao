import os, json, secrets, gzip
from datetime import datetime
from functools import wraps
from io import BytesIO
from flask import Flask, render_template, render_template_string, request, jsonify, session, redirect, url_for, send_file, abort, Response
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import select
from sqlalchemy.orm.attributes import flag_modified
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv('SECRET_KEY') or secrets.token_hex(32),
    MAX_CONTENT_LENGTH=20 * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=os.getenv('RENDER','').lower()=='true'
)

db_url=os.getenv('DATABASE_URL','sqlite:///transformacao_kaz.db')
if db_url.startswith('postgres://'): db_url=db_url.replace('postgres://','postgresql://',1)
if db_url.startswith('postgresql://'): db_url=db_url.replace('postgresql://','postgresql+psycopg://',1)
app.config['SQLALCHEMY_DATABASE_URI']=db_url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
db=SQLAlchemy(app)

PROJECT_STATUSES=['Não iniciado','Em andamento','Em risco','Concluído']
DEPENDENCY_STATUSES=['Aberta','Em análise','Respondida','Resolvida']
DIRECTOR_NAMES=['Rachid','Leo','Márcio','Marcinho']
DIRECTOR_USERNAMES=['rachid','leo','marcio','marcinho']

class User(db.Model):
    __tablename__='kaz_users'
    id=db.Column(db.Integer,primary_key=True)
    username=db.Column(db.String(80),unique=True,nullable=False)
    display_name=db.Column(db.String(160),nullable=False)
    password_hash=db.Column(db.String(255),nullable=False)
    role=db.Column(db.String(30),nullable=False,default='owner')
    project_id=db.Column(db.String(80))
    active=db.Column(db.Boolean,nullable=False,default=True)
    created_at=db.Column(db.DateTime,default=datetime.utcnow)

class AppState(db.Model):
    __tablename__='kaz_app_state'
    id=db.Column(db.Integer,primary_key=True,default=1)
    payload=db.Column(db.JSON,nullable=False)
    revision=db.Column(db.Integer,nullable=False,default=1)
    updated_by=db.Column(db.String(160))
    updated_at=db.Column(db.DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)

class Attachment(db.Model):
    __tablename__='kaz_attachments'
    id=db.Column(db.Integer,primary_key=True)
    project_id=db.Column(db.String(80),nullable=False,index=True)
    milestone_id=db.Column(db.String(120),index=True)
    name=db.Column(db.String(255),nullable=False)
    note=db.Column(db.String(500))
    mime_type=db.Column(db.String(180))
    size=db.Column(db.Integer,nullable=False)
    file_data=db.Column(db.LargeBinary,nullable=False)
    uploaded_by=db.Column(db.String(160))
    created_at=db.Column(db.DateTime,default=datetime.utcnow)

OWNER_SEEDS=[
    ('ana','Ana Silvia','owner','comercial'),('oscar','Oscar','owner','projetos'),
    ('raquel','Raquel','owner','posvenda'),('ju','Ju Hirota','owner','producao'),
    ('wancler','Wancler','owner','compras'),('erik','Erik','owner','financeiro'),
    ('vini','Vini','owner','planejamento'),('marcio','Márcio','direction',None),
    ('marcinho','Marcinho','direction',None),('leo','Leo','direction',None)
]

def now_iso(): return datetime.utcnow().replace(microsecond=0).isoformat()+'Z'
def load_seed():
    with open(os.path.join(app.root_path,'seed_state.json'),encoding='utf-8') as f: return json.load(f)

def normalize_state(payload):
    changed=False
    if not isinstance(payload,dict): payload=load_seed(); changed=True
    else: payload=json.loads(json.dumps(payload,ensure_ascii=False))
    payload.setdefault('dependencies',[]); payload.setdefault('meetings',[]); payload['direction']=DIRECTOR_NAMES
    if int(payload.get('schemaVersion') or 1) < 3:
        payload['schemaVersion']=3; changed=True
    for p in payload.get('projects',[]):
        if p.get('status') not in PROJECT_STATUSES: p['status']='Não iniciado'; changed=True
        for key,default in [('generalMemos',[]),('files',[]),('weeklyCommitments',[]),('history',[])]:
            if key not in p: p[key]=default.copy(); changed=True
        p.setdefault('lastUpdate',''); p.setdefault('validated',False)
        if 'milestonesLocked' not in p: p['milestonesLocked']=False; changed=True
        if 'milestonesLockedAt' not in p: p['milestonesLockedAt']=''; changed=True
        if 'milestonesLockedBy' not in p: p['milestonesLockedBy']=''; changed=True
        for m in p.get('milestones',[]):
            if m.get('status') not in PROJECT_STATUSES: m['status']='Não iniciado'; changed=True
            m.setdefault('memos',[]); m.setdefault('files',[]); m.setdefault('deadline',''); m.setdefault('conclusion',''); m.setdefault('concludedAt','')
    for d in payload.get('dependencies',[]):
        d.setdefault('history',[]); d.setdefault('responses',[]); d.setdefault('comments',[]); d.setdefault('messages',[])
        if d.get('status') not in DEPENDENCY_STATUSES: d['status']='Aberta'; changed=True
        d.setdefault('director',''); d.setdefault('resolution','')
    return payload,changed

def seed_if_empty():
    state=db.session.get(AppState,1)
    if not state:
        db.session.add(AppState(id=1,payload=load_seed(),revision=1,updated_by='Sistema'))
    else:
        normalized,changed=normalize_state(state.payload)
        if changed:
            state.payload=normalized; flag_modified(state,'payload'); state.revision+=1
            state.updated_by='Migração V3'; state.updated_at=datetime.utcnow()
    admin_username=os.getenv('ADMIN_USERNAME','rachid').strip().lower()
    admin_password=os.getenv('ADMIN_PASSWORD') or 'change-me-now'
    admin=User.query.filter_by(username=admin_username).first()
    if not admin:
        db.session.add(User(username=admin_username,display_name='Rachid',password_hash=generate_password_hash(admin_password),role='admin',active=True))
    for username,name,role,pid in OWNER_SEEDS:
        u=User.query.filter_by(username=username).first()
        if not u:
            db.session.add(User(username=username,display_name=name,password_hash=generate_password_hash(secrets.token_urlsafe(32)),role=role,project_id=pid,active=False))
        else:
            u.display_name=name; u.role=role; u.project_id=pid
    db.session.commit()

def current_user():
    uid=session.get('user_id'); return db.session.get(User,uid) if uid else None

def login_required(fn):
    @wraps(fn)
    def wrapped(*a,**kw):
        u=current_user()
        if not u or not u.active:
            session.clear()
            if request.path.startswith('/api/'): return jsonify({'error':'unauthorized'}),401
            return redirect(url_for('login'))
        return fn(*a,**kw)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapped(*a,**kw):
        if current_user().role!='admin': abort(403)
        return fn(*a,**kw)
    return wrapped

def require_csrf():
    token=request.headers.get('X-CSRF-Token') or request.form.get('csrf_token')
    if not token or not secrets.compare_digest(token,session.get('csrf','')): abort(403)

def is_director(u): return bool(u and (u.role in ('admin','direction') or u.username in DIRECTOR_USERNAMES))
def public_user(u): return {'id':u.id,'username':u.username,'display_name':u.display_name,'role':u.role,'project_id':u.project_id,'active':u.active,'is_director':is_director(u)}
def can_edit_project(u,pid): return bool(u and (is_director(u) or (u.role=='owner' and u.project_id==pid)))
def find_project(payload,pid): return next((p for p in payload.get('projects',[]) if p.get('id')==pid),None)
def find_dependency(payload,did): return next((d for d in payload.get('dependencies',[]) if str(d.get('id'))==str(did)),None)
def append_history(dep,action,actor,detail=''):
    dep.setdefault('history',[]).append({'at':now_iso(),'actor':actor.display_name,'action':action,'detail':detail}); dep['updatedAt']=now_iso()

def touch_state(s,u):
    flag_modified(s,'payload'); s.revision+=1; s.updated_by=u.display_name; s.updated_at=datetime.utcnow(); db.session.commit()

def safe_project_write(pid):
    u=current_user()
    if not can_edit_project(u,pid): abort(403)
    s=db.session.execute(select(AppState).where(AppState.id==1).with_for_update()).scalar_one()
    p=find_project(s.payload,pid)
    if not p: abort(404)
    return s,p,u

@app.route('/health')
def health(): return jsonify({'ok':True,'service':'transformacao-kaz','version':'3.0'})

@app.route('/login',methods=['GET','POST'])
def login():
    if current_user() and current_user().active: return redirect(url_for('index'))
    error=None
    if request.method=='POST':
        u=User.query.filter_by(username=request.form.get('username','').strip().lower()).first(); password=request.form.get('password','')
        if u and u.active and check_password_hash(u.password_hash,password):
            session.clear(); session['user_id']=u.id; session['csrf']=secrets.token_urlsafe(24); return redirect(url_for('index'))
        error='Usuário ou senha inválidos.'
    return render_template('login.html',error=error)

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

@app.route('/')
@login_required
def index():
    s=db.session.get(AppState,1)
    
    template_path=os.path.join(app.root_path,'templates','index.html.gz')
    with gzip.open(template_path,'rt',encoding='utf-8') as f: template_source=f.read()
    return render_template_string(template_source,initial_state=s.payload,revision=s.revision,user=public_user(current_user()),csrf=session['csrf'],directors=DIRECTOR_NAMES)

@app.route('/manual')
@login_required
def manual():
    content = """<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'><title>Manual do Usuário - Transformação KAZ</title><style>body{font-family:Arial,sans-serif;max-width:900px;margin:40px auto;padding:0 24px;color:#17283b;line-height:1.55}h1,h2{color:#0f1d2d}h2{margin-top:32px;border-bottom:1px solid #ddd;padding-bottom:6px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:8px;text-align:left}.note{background:#f5f7fa;padding:14px;border-radius:8px}</style></head><body>
<h1>Manual do Usuário — Transformação KAZ</h1>
<p><b>Objetivo:</b> acompanhar a implantação da nova estrutura da KAZ por projetos, marcos, compromissos semanais, decisões e pendências externas. O sistema não é um gerenciador de microtarefas.</p>
<h2>1. Governança</h2><p>Diretoria: Rachid, Leo, Márcio e Marcinho. Eles podem ver e alterar todos os projetos, responder pendências e destravar decisões. Donos: Ana Silvia (Comercial), Oscar (Projetos / Assessor), Raquel (Pós-venda), Ju Hirota (Produção), Wancler (Compras), Erik (Financeiro) e Vini (Planejamento Financeiro). Todos podem consultar tudo, mas cada dono altera apenas o próprio projeto.</p>
<h2>2. Marcos</h2><p>Marcos são etapas relevantes da transformação. A Visão Geral mostra um resumo inteligente; a aba Marcos mostra todos. Cada dono tem uma única rodada para revisar e finalizar a estrutura dos marcos. Depois de finalizar, a estrutura fica bloqueada para ele. A Diretoria mantém permissão de ajuste excepcional.</p>
<h2>3. Pendências externas</h2><p>Uma pendência só deve ser criada quando o projeto depende da Diretoria. Cada pendência tem um único diretor responsável: Rachid, Leo, Márcio ou Marcinho. Status: Aberta, Em análise, Respondida e Resolvida. Qualquer diretor pode responder; o diretor designado é quem formalmente assume. O dono do projeto ou a Diretoria podem resolver e reabrir, com motivo obrigatório.</p>
<h2>4. Reunião de quarta-feira</h2><p>A reunião semanal é o motor do sistema. A sequência recomendada é: (1) recuperar o que ficou combinado; (2) comparar prometido x realizado; (3) registrar andamento, contexto e decisões; (4) definir o que precisa estar diferente até a próxima quarta-feira; (5) abrir pendências externas quando necessário.</p>
<div class='note'><b>Microfone:</b> o dono do projeto inicia o microfone ao começar sua apresentação. O sistema registra o áudio, tenta transcrever a conversa no navegador e permite gerar um resumo. Ao final, a transcrição e o resumo devem ser revisados antes de fechar a reunião.</div>
<h2>5. Compromissos semanais</h2><p>Compromissos devem descrever resultados esperados, não pequenas tarefas. Na reunião seguinte eles são avaliados como Realizado, Parcial ou Não realizado.</p>
<h2>6. Ajuda e Configurações</h2><p>O menu Ajuda reúne este manual e um tutorial tela a tela. Em Configurações, cada usuário pode alterar a própria senha.</p>
<h2>7. Regra central</h2><p><b>Qual é o próximo avanço real do seu projeto, quando você entrega e de quem você depende?</b></p>
</body></html>"""
    return Response(content, mimetype='text/html', headers={'Content-Disposition':'attachment; filename=Manual_Usuario_Transformacao_KAZ.html'})

@app.route('/api/state')
@login_required
def api_get_state():
    s=db.session.get(AppState,1)
    return jsonify({'state':s.payload,'revision':s.revision,'updated_by':s.updated_by,'updated_at':s.updated_at.isoformat() if s.updated_at else None})

@app.route('/api/password',methods=['POST'])
@login_required
def change_password():
    require_csrf(); body=request.get_json(force=True); u=current_user()
    current=(body.get('current_password') or ''); new=(body.get('new_password') or ''); confirm=(body.get('confirm_password') or '')
    if not check_password_hash(u.password_hash,current): return jsonify({'error':'Senha atual incorreta.'}),400
    if len(new)<8: return jsonify({'error':'A nova senha precisa ter pelo menos 8 caracteres.'}),400
    if new!=confirm: return jsonify({'error':'A confirmação da nova senha não confere.'}),400
    if current==new: return jsonify({'error':'Escolha uma senha diferente da atual.'}),400
    u.password_hash=generate_password_hash(new); db.session.commit()
    return jsonify({'ok':True})

@app.route('/api/projects/<project_id>',methods=['POST'])
@login_required
def project_action(project_id):
    require_csrf(); body=request.get_json(force=True); action=body.get('action'); s,p,u=safe_project_write(project_id)
    owner=(u.role=='owner' and u.project_id==project_id and not is_director(u))
    if action=='status':
        status=body.get('status');
        if status not in PROJECT_STATUSES: return jsonify({'error':'invalid_status'}),400
        p['status']=status
    elif action=='objective':
        p['objective']=(body.get('objective') or '').strip()
    elif action=='validated':
        if not is_director(u): abort(403)
        p['validated']=bool(body.get('value'))
    elif action=='general_memo':
        text=(body.get('text') or '').strip()
        if not text: return jsonify({'error':'text_required'}),400
        p.setdefault('generalMemos',[]).append({'at':now_iso(),'author':u.display_name,'text':text})
        p['lastUpdate']=now_iso()
    elif action=='milestones_finalize':
        if not owner: abort(403)
        if p.get('milestonesLocked'): return jsonify({'error':'Os marcos já foram finalizados e estão bloqueados para o responsável.'}),400
        updates=body.get('milestones')
        if not isinstance(updates,list) or not updates: return jsonify({'error':'milestones_required'}),400
        byid={str(m.get('id')):m for m in p.get('milestones',[])}
        for item in updates:
            m=byid.get(str(item.get('id')))
            if not m: continue
            st=item.get('status')
            if st in PROJECT_STATUSES: m['status']=st
            m['deadline']=item.get('deadline','') or ''
            m['conclusion']=item.get('conclusion','') or ''
            memo=(item.get('memo') or '').strip()
            if memo: m.setdefault('memos',[]).append({'at':now_iso(),'author':u.display_name,'text':memo})
        p['milestonesLocked']=True; p['milestonesLockedAt']=now_iso(); p['milestonesLockedBy']=u.display_name; p['lastUpdate']=now_iso()
        p.setdefault('history',[]).append({'at':now_iso(),'author':u.display_name,'text':'Edição inicial dos marcos finalizada e bloqueada.'})
    elif action=='milestone':
        if owner and p.get('milestonesLocked'): return jsonify({'error':'Os marcos já foram finalizados e não podem mais ser editados pelo responsável.'}),403
        if owner: return jsonify({'error':'Use a edição única de marcos e finalize todos de uma vez.'}),400
        mid=str(body.get('milestoneId')); m=next((x for x in p.get('milestones',[]) if str(x.get('id'))==mid),None)
        if not m: abort(404)
        st=body.get('status')
        if st in PROJECT_STATUSES: m['status']=st
        m['deadline']=body.get('deadline','') or ''; m['conclusion']=body.get('conclusion','') or ''
        memo=(body.get('memo') or '').strip()
        if memo: m.setdefault('memos',[]).append({'at':now_iso(),'author':u.display_name,'text':memo})
        p['lastUpdate']=now_iso()
    elif action=='unlock_milestones':
        if not is_director(u): abort(403)
        p['milestonesLocked']=False; p['milestonesLockedAt']=''; p['milestonesLockedBy']=''
        p.setdefault('history',[]).append({'at':now_iso(),'author':u.display_name,'text':'Diretoria reabriu a edição dos marcos para o responsável.'})
    elif action=='weekly_commitment':
        text=(body.get('text') or '').strip()
        if not text: return jsonify({'error':'text_required'}),400
        p.setdefault('weeklyCommitments',[]).append({'id':secrets.token_hex(6),'text':text,'status':'Aberto','author':u.display_name,'createdAt':now_iso()})
    elif action=='commitment_status':
        cid=str(body.get('commitmentId')); status=body.get('status')
        if status not in ['Aberto','Realizado','Parcial','Não realizado']: return jsonify({'error':'invalid_status'}),400
        c=next((x for x in p.get('weeklyCommitments',[]) if str(x.get('id'))==cid),None)
        if not c: abort(404)
        c['status']=status; c['updatedAt']=now_iso()
    else: return jsonify({'error':'invalid_action'}),400
    touch_state(s,u); return jsonify({'ok':True,'revision':s.revision})

@app.route('/api/dependencies',methods=['POST'])
@login_required
def create_dependency():
    require_csrf(); body=request.get_json(force=True); u=current_user(); pid=body.get('projectId','')
    if not can_edit_project(u,pid): abort(403)
    director=(body.get('director') or '').strip(); subject=(body.get('subject') or '').strip(); description=(body.get('description') or '').strip()
    if director not in DIRECTOR_NAMES or not subject: return jsonify({'error':'invalid_dependency'}),400
    s=db.session.execute(select(AppState).where(AppState.id==1).with_for_update()).scalar_one()
    if not find_project(s.payload,pid): abort(404)
    dep={'id':secrets.token_hex(8),'projectId':pid,'requester':u.display_name,'createdBy':u.username,'subject':subject,'description':description,'director':director,'deadline':body.get('deadline',''),'status':'Aberta','createdAt':now_iso(),'updatedAt':now_iso(),'responses':[],'comments':[],'messages':[],'history':[],'resolution':''}
    append_history(dep,'Pendência aberta',u,f'Diretor responsável: {director}')
    s.payload.setdefault('dependencies',[]).append(dep); touch_state(s,u)
    return jsonify({'ok':True,'dependency':dep,'revision':s.revision})

@app.route('/api/dependencies/<dep_id>/action',methods=['POST'])
@login_required
def dependency_action(dep_id):
    require_csrf(); u=current_user(); body=request.get_json(force=True); action=body.get('action')
    s=db.session.execute(select(AppState).where(AppState.id==1).with_for_update()).scalar_one(); dep=find_dependency(s.payload,dep_id)
    if not dep: abort(404)
    own=u.role=='owner' and u.project_id==dep.get('projectId'); director=is_director(u); text=(body.get('text') or body.get('note') or body.get('reason') or '').strip()
    if action=='assume':
        if not director or u.display_name!=dep.get('director'): abort(403)
        if dep.get('status')=='Resolvida': return jsonify({'error':'resolved'}),400
        dep['status']='Em análise'; append_history(dep,'Pendência assumida',u)
    elif action=='respond':
        if not director: abort(403)
        if not text: return jsonify({'error':'text_required'}),400
        msg={'at':now_iso(),'actor':u.display_name,'text':text,'type':'director'}; dep.setdefault('responses',[]).append(msg); dep.setdefault('messages',[]).append(msg)
        dep['status']='Respondida'; append_history(dep,'Resposta da Diretoria',u,text)
    elif action=='comment':
        if not (director or own): abort(403)
        if not text: return jsonify({'error':'text_required'}),400
        msg={'at':now_iso(),'actor':u.display_name,'text':text,'type':'comment'}; dep.setdefault('comments',[]).append(msg); dep.setdefault('messages',[]).append(msg)
        append_history(dep,'Informação adicionada',u,text)
    elif action=='resolve':
        if not (director or own): abort(403)
        dep['status']='Resolvida'; dep['resolution']=text; append_history(dep,'Pendência resolvida',u,text or 'Encerrada')
    elif action=='reopen':
        if not (director or own): abort(403)
        if dep.get('status')!='Resolvida': return jsonify({'error':'not_resolved'}),400
        if not text: return jsonify({'error':'reason_required'}),400
        dep['status']='Em análise'; append_history(dep,'Pendência reaberta',u,text)
    elif action in ('change_director','reassign'):
        if not director: abort(403)
        nd=(body.get('director') or '').strip()
        if nd not in DIRECTOR_NAMES: return jsonify({'error':'invalid_director'}),400
        old=dep.get('director'); dep['director']=nd; append_history(dep,'Diretor responsável alterado',u,f'{old} → {nd}. {text}'.strip())
    elif action=='change_deadline':
        if not (director or own): abort(403)
        old=dep.get('deadline',''); dep['deadline']=body.get('deadline',''); append_history(dep,'Prazo alterado',u,f'{old or "sem prazo"} → {dep["deadline"] or "sem prazo"}')
    else: return jsonify({'error':'invalid_action'}),400
    touch_state(s,u); return jsonify({'ok':True,'dependency':dep,'revision':s.revision})

@app.route('/api/meetings',methods=['POST'])
@login_required
def create_meeting():
    require_csrf(); body=request.get_json(force=True); u=current_user(); pid=body.get('projectId','')
    if not can_edit_project(u,pid): abort(403)
    s=db.session.execute(select(AppState).where(AppState.id==1).with_for_update()).scalar_one(); p=find_project(s.payload,pid)
    if not p: abort(404)
    meeting={'id':secrets.token_hex(7),'projectId':pid,'at':now_iso(),'createdBy':u.display_name,'notes':(body.get('notes') or '').strip(),'decisions':(body.get('decisions') or '').strip(),'nextWeek':(body.get('nextWeek') or '').strip(),'transcript':(body.get('transcript') or '').strip(),'summary':(body.get('summary') or '').strip()}
    s.payload.setdefault('meetings',[]).append(meeting); p['lastUpdate']=now_iso()
    if meeting['nextWeek']:
        p.setdefault('weeklyCommitments',[]).append({'id':secrets.token_hex(6),'text':meeting['nextWeek'],'status':'Aberto','author':u.display_name,'createdAt':now_iso(),'source':'meeting'})
    touch_state(s,u); return jsonify({'ok':True,'meeting':meeting,'revision':s.revision})

@app.route('/api/attachments',methods=['POST'])
@login_required
def upload_attachment():
    require_csrf(); f=request.files.get('file')
    if not f or not f.filename: return jsonify({'error':'missing_file'}),400
    data=f.read()
    if len(data)>20*1024*1024: return jsonify({'error':'too_large'}),413
    pid=request.form.get('project_id',''); u=current_user()
    if not can_edit_project(u,pid): abort(403)
    a=Attachment(project_id=pid,milestone_id=request.form.get('milestone_id') or None,name=secure_filename(f.filename) or 'arquivo',note=request.form.get('note','').strip(),mime_type=f.mimetype,size=len(data),file_data=data,uploaded_by=u.display_name)
    db.session.add(a); db.session.commit()
    return jsonify({'id':a.id,'name':a.name,'size':a.size,'note':a.note,'date':a.created_at.strftime('%d/%m/%Y %H:%M'),'url':url_for('download_attachment',attachment_id=a.id)})

@app.route('/attachments/<int:attachment_id>')
@login_required
def download_attachment(attachment_id):
    a=db.session.get(Attachment,attachment_id)
    if not a: abort(404)
    return send_file(BytesIO(a.file_data),mimetype=a.mime_type or 'application/octet-stream',as_attachment=True,download_name=a.name)

@app.route('/api/users')
@login_required
def api_users(): return jsonify([public_user(u) for u in User.query.order_by(User.display_name).all()])

@app.route('/admin/users',methods=['GET','POST'])
@admin_required
def admin_users():
    message=error=None
    if request.method=='POST':
        require_csrf(); u=db.session.get(User,int(request.form['user_id']))
        if not u: abort(404)
        u.display_name=request.form.get('display_name',u.display_name).strip() or u.display_name; u.active=request.form.get('active')=='on'; password=request.form.get('password','')
        if password:
            if len(password)<8: error='A senha precisa ter pelo menos 8 caracteres.'
            else: u.password_hash=generate_password_hash(password)
        if not error: db.session.commit(); message=f'Usuário {u.display_name} atualizado.'
    users=User.query.order_by(User.display_name).all(); state=db.session.get(AppState,1).payload; projects=[(p['id'],p['name']) for p in state.get('projects',[])]
    return render_template('users.html',users=users,projects=projects,csrf=session['csrf'],message=message,error=error)

with app.app_context():
    db.create_all(); seed_if_empty()

if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.getenv('PORT','5000')),debug=os.getenv('FLASK_DEBUG')=='1')
